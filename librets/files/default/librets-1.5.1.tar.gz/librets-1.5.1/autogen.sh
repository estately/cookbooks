#! /bin/sh

autoconf --force
